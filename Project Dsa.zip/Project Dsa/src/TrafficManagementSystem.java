public class TrafficManagementSystem {

    // Custom Queue implementation
    private static class Queue {
        private Node front, rear;
        private int size;

        private static class Node {
            String data;
            Node next;

            Node(String data) {
                this.data = data;
                this.next = null;
            }
        }

        public Queue() {
            this.front = this.rear = null;
            this.size = 0;
        }

        public void offer(String data) {
            Node newNode = new Node(data);
            if (rear == null) {
                front = rear = newNode;
            } else {
                rear.next = newNode;
                rear = newNode;
            }
            size++;
        }

        public String poll() {
            if (front == null) {
                return null;
            }
            String data = front.data;
            front = front.next;
            if (front == null) {
                rear = null;
            }
            size--;
            return data;
        }

        public boolean isEmpty() {
            return front == null;
        }

        public int size() {
            return size;
        }

        public void display() {
            Node current = front;
            while (current != null) {
                System.out.print(current.data + " -> ");
                current = current.next;
            }
            System.out.println("null");
        }
    }

    private Queue vehicleQueue;
    private int greenLightDuration; // Duration for which the light remains green (in seconds)

    public TrafficManagementSystem(int greenLightDuration) {
        this.vehicleQueue = new Queue();
        this.greenLightDuration = greenLightDuration;
    }

    // Simulates the arrival of vehicles at the intersection
    public void simulateVehicleArrival(int numberOfVehicles) {
        for (int i = 1; i <= numberOfVehicles; i++) {
            String vehicle = "Vehicle-" + i;
            vehicleQueue.offer(vehicle);
            System.out.println(vehicle + " has arrived and joined the queue.");
        }
    }

    // Processes vehicles at the green light
    public void processGreenLight() {
        System.out.println("\nGreen light is ON. Processing vehicles...");
        long startTime = System.currentTimeMillis();

        while (!vehicleQueue.isEmpty() &&
                (System.currentTimeMillis() - startTime) / 1000 < greenLightDuration) {
            String departingVehicle = vehicleQueue.poll();
            System.out.println(departingVehicle + " has departed.");
        }

        if (vehicleQueue.isEmpty()) {
            System.out.println("All vehicles have cleared the intersection.");
        } else {
            System.out.println("Green light turned OFF. Vehicles remaining in the queue: " + vehicleQueue.size());
        }
    }

    public void displayQueueStatus() {
        System.out.println("\nCurrent queue status:");
        if (vehicleQueue.isEmpty()) {
            System.out.println("No vehicles in the queue.");
        } else {
            vehicleQueue.display();
        }
    }

    public static void main(String[] args) {
        // Initialize the traffic management system
        TrafficManagementSystem trafficSystem = new TrafficManagementSystem(5); // Green light duration: 5 seconds

        // Simulate vehicle arrivals
        trafficSystem.simulateVehicleArrival(10);

        // Display queue status
        trafficSystem.displayQueueStatus();

        // Process vehicles at green light
        trafficSystem.processGreenLight();

        // Display queue status after processing
        trafficSystem.displayQueueStatus();
    }
}
